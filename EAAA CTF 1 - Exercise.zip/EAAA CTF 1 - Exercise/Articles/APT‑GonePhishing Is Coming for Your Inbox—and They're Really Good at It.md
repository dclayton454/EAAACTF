### 🌐 _Crabs on Security_ 

**Title:** _APT‑GonePhishing Is Coming for Your Inbox—and They're Really Good at It_

APT‑GonePhishing isn’t your typical scammer. They’re a highly advanced hacking group who **pretend to be people you trust**, from recruiters and partner firms to NGOs or government officials. Their main goal? **To spy on important sectors**—like government, finance, defense, and even maritime shipping.

Here’s what they do differently:

- They send emails with documents that look normal—like invoices, policy files, or hiring forms. But opening them can trigger a hidden exploit (like “Follina”) that gives them access to your computer.
    
- They create entire fake companies—complete with LinkedIn profiles and websites—to trick people into trusting their messages.
    
- They use sneaky tools to **steal your session cookies**—meaning they can pretend to be you online even if you use multi-factor authentication.
    
- Once inside, they quietly gather information, archive it into hidden 7-Zip files (sometimes disguised in photos), and send it out using secure web tricks or email drafts you’d never notice.
    
- Their emails often come from **real marketing platforms**, so spam filters don’t catch them.
    

✅ **What you can do:**

1. Be cautious about **unexpected job offers** or collaboration requests, especially from new companies.
    
2. Keep software updated—especially Outlook, Word, and browsers.
    
3. Use **security tools that detect behavior**, not just malware.
    
4. Monitor your cloud accounts for strange logins or new devices.
    
5. Don’t ignore unusual “email drafts” in your mailbox—they might be a hacker’s command center.
    

APT‑GonePhishing teaches us that **hacks today often start with hello**—and the most dangerous email might be the one that seems boring.