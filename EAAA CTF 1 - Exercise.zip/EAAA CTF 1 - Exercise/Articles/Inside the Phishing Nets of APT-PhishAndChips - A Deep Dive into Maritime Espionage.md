## **Freaking Computer

**"Inside the Phishing Nets of APT-PhishAndChips: A Deep Dive into Maritime Espionage"**

In early 2025, a European freight forwarding firm noticed something odd: several cargo deliveries had been mysteriously delayed, yet their IT systems showed no signs of breach. What investigators found was a lesson in subtlety — and the calling card of **APT-PhishAndChips**.

This group has built a reputation for **industry-specific mimicry**. Their fake customs clearance forms and shipping invoices aren’t generic — they’re tailored with correct terminology, formatting, and even internal reference codes scraped from previous compromises. Former security consultant “E.L.,” who has tracked the group for two years, told us:

> “They don’t just send malware. They send _context_. That’s what makes their phishing nearly impossible to filter out without also blocking legitimate business.”

Technically, their campaigns blend well-known tactics with sector-specific innovations:

- **Steganographic exfiltration** — hiding stolen route and manifest data inside image files of maritime maps.
    
- **DNS tunneling from satellite comms** — leveraging channels most security teams never check.
    
- **Opportunistic encryption** — locking up port scheduling databases just long enough to create chaos during an ongoing theft.
    

This isn’t the first time the shipping world has been hit by a nation-aligned group. In 2017, NotPetya crippled Maersk’s operations for weeks, but that was a blunt instrument. PhishAndChips is the scalpel — precise, selective, and quiet unless they want noise.

When asked about motivation, maritime cybersecurity analyst Dr. Lorna Graves said:

> “They’re after two things: intelligence that helps their state’s trade advantage, and the occasional quick profit. But make no mistake — they’re disciplined, and they know the shipping sector is both vulnerable and under-defended.”

The investigation concluded that the attackers maintained access to multiple targets for months at a time, often rotating between them to avoid triggering alarms. Evidence suggests at least one active campaign is still underway against a major LNG terminal operator.