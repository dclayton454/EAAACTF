## **📰 Freaking Computer

**Title:** _Click, Switch, Lock: How APT-ClickBaitAndSwitch Took Over a Global Ad Network_

The breach at AdSphere Media started like a marketing success story: a blog post going viral during the largest advertising expo of the year. But the source was an attacker-run site, carefully staged with clean content for the first wave of visitors.

Only after analytics showed repeat visits from corporate IP ranges did the site flip to serve malicious JavaScript from a compromised ad network slot. Around the same time, employees were offered a free “TrendBoost” SEO tool via internal chat — a trojanized package that injected persistence code into Windows registry run keys.

Network traffic analysis revealed that infected systems communicated with attacker servers hidden inside ordinary ad delivery traffic. This traffic also carried back stolen credentials, which were quickly used to take over the brand’s official social media accounts. Those accounts began posting new “exclusive” stories, driving even more clicks back to attacker infrastructure.

Forensic review of exfiltration logs showed that large sets of consumer engagement metrics and advertiser billing data were uploaded to what appeared to be an ad verification service. The final blow came days later: ransomware deployed on two of the company’s high-traffic ad servers, crippling operations for 48 hours.

APT-ClickBaitAndSwitch’s precision timing and layered approach make them a hybrid threat — part social engineer, part infrastructure saboteur.