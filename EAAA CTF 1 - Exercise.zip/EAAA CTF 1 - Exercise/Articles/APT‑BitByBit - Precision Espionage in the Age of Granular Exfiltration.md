### 🧭 Version3

**Title:** _APT‑BitByBit: Precision Espionage in the Age of Granular Exfiltration_

APT‑BitByBit exemplifies the modern doctrine of **stealth-first cyberespionage**. While many threat actors seek speed and scale, this Southeast Asian-based group pursues **incremental theft over months or years**, quietly siphoning high-value intellectual property with surgical precision.

Their operations are anchored in **byte-level exfiltration**, using tools like `DNSplice` and `BitShred` to split sensitive data into small, obfuscated pieces. DNS tunneling (T1048.003) remains a favored tactic—abusing a protocol so fundamental to network operations that it's rarely monitored for anomalies at this granularity.

APT‑BitByBit maintains a hybrid approach that fuses **LOtL techniques**, such as batch scripting and hidden local user accounts, with **custom steganography and encoding frameworks** (e.g., `EnigmaChunk`, `ByteDecoder`). Their persistence mechanisms are intentionally low-profile: command shell automation, process scanning to avoid detection, and cloud-based reassembly endpoints spun up and torn down in short windows.

Of strategic note is the group's **target prioritization**, which often begins with discovery of CAD software or R&D application windows (T1010), followed by data staging, encoding, and trickle-out exfiltration.

This actor represents a **long-game threat model**: slow, stealthy, and patient. The biggest challenge for defenders is not perimeter defense, but **time-based detection of anomalies at the data layer**. Solutions must evolve beyond volumetric thresholds and toward behavioral insights that detect the deliberate crawl of intellectual theft—bit by bit.