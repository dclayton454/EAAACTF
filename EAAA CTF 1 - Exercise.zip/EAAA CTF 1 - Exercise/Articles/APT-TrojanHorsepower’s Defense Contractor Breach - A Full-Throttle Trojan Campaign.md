## **📰 Freaking Computer

**Title:** _APT-TrojanHorsepower’s Defense Contractor Breach: A Full-Throttle Trojan Campaign_

Forensics from the breach at SecureDef Systems reveal a multi-phase intrusion beginning with exploitation of a vulnerable public-facing HR portal. Once inside, the attackers deployed web shells for remote command execution and followed with PowerShell scripts to install trojan payloads directly into memory.

Persistence was achieved through the creation of system services with misleading names and hidden scheduled tasks. Shortly after, Mimikatz was run to dump cached credentials, enabling pass-the-hash lateral movement into classified project servers. WMI execution allowed the attackers to spread without deploying fresh binaries, further reducing detection risk.

During the intrusion, endpoint protection services were quietly disabled, and the attackers used SMB to transfer additional tools to compromised hosts. Sensitive design blueprints were exfiltrated over HTTPS using the trojan’s built-in C2 channel.

The incident concluded with targeted disk wiping on select endpoints, suggesting an intent to destroy evidence and disrupt recovery. SecureDef estimates data theft occurred over a 12-day window before the wipe, with the attackers maintaining a consistent, low-profile presence throughout.