## **Freaking Computer

**Title:** _APT-Botnetflix’s Telecom Heist: Anatomy of a Multi-Layered Botnet Operation_

The breach of CelerTel, a major regional telecom, was not the work of a lone hacker — it was a coordinated campaign orchestrated by APT-Botnetflix.

Initial entry was achieved through quietly deployed web shells on several public-facing servers. Forensic analysis shows these shells were accessed via standard HTTPS requests from seemingly benign IP ranges, an effective camouflage tactic.

Next came the storm. Within hours, a multi-tiered botnet composed of compromised IoT cameras, routers, and workstations began flooding CelerTel’s DNS and customer login portals with traffic spikes peaking at 800 Gbps. This crippled customer service access and kept incident response teams scrambling.

While the public and technical teams focused on restoring service, investigators found that encrypted command-and-control traffic was simultaneously moving out of the network, containing compressed archives of customer records and employee credentials. Several of these credentials were later used to access internal admin consoles — evidence of a pass-the-hash lateral movement.

APT-Botnetflix’s infrastructure logs show they also leveraged SMTP spam waves during the attack, distributing phishing payloads to telecom customers. This not only expanded their botnet footprint but also helped mask the C2 traffic among legitimate email flows.

Botnet historian Marcus Vey compared this operation to APT-CTRLAltDeceit’s 2022 energy sector breach: “Both used overwhelming DDoS to cover espionage, but Botnetflix’s integration of multiple protocol-based controls and exfiltration channels makes them more dangerous. They’ve turned the botnet into a Swiss Army knife of cyber operations.”