## **📰 Freaking Computer

**Title:** _Inside Lynx’s Energy Sector Attack: A 48-Hour Takeover_

Incident responders investigating the Lynx intrusion at EuroGrid Energy found a rapid, two-pronged entry. Phishing emails with weaponized attachments coincided with an exploit against an outdated VPN service. From there, the attackers authenticated with stolen accounts and set up persistence using scheduled tasks and registry startup modifications.

Defense evasion was immediate — antivirus services terminated, SQL backups halted, and shadow copies deleted. The attackers expanded laterally via SMB shares to reach file servers, while RDP connections were established to domain controllers and critical application servers.

Exfiltration began before encryption. Sensitive legal contracts, operational documents, and customer data were uploaded to a Lynx-controlled web panel for affiliate management. Encryption followed, with the malware appending “.lynx” to all targeted files. Desktops were replaced with ransom note wallpapers, and networked printers were triggered to print ransom demands simultaneously across offices.

Investigators concluded that the attackers leveraged Lynx’s centralized leak site as part of a double-extortion model, threatening public release to pressure a ransom payment.