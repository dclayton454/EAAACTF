## **📰 Crabs on Security

**Title:** _When That Juicy Headline Is a Trap: The APT-ClickBaitAndSwitch Scam_

Ever clicked a link that promised “The Shocking Truth About…” only to get something totally different? That’s APT-ClickBaitAndSwitch’s whole business model — except their “switch” doesn’t just disappoint, it steals.

They start with links you actually _want_ to click: breaking news in your industry, freebies, giveaways. The first time you visit, it’s harmless. But the second or third time? The site quietly installs malicious code.

Sometimes they offer a free tool — an SEO booster, a social media analytics app — that’s actually hiding malware. Once you run it, it makes sure it restarts every time your computer does.

The attackers then talk to your infected machine through normal-looking web traffic that blends in with ads and tracking pixels. They may also hijack real company social media accounts (after stealing the login) to post even more tempting links, this time from a trusted source.

The real sting comes later: stolen marketing data sent to fake “verification” services, and — in some cases — ransomware that locks up advertising servers until a ransom is paid.