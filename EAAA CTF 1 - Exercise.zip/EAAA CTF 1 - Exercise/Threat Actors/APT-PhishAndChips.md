**Overview:**  
APT-PhishAndChips is a highly resourceful, UK-based state-aligned cyber group with a flair for social engineering and maritime-themed deception campaigns. Their name comes from their habit of “fishing” for credentials using British cultural quirks — emails full of dry humor, tea references, and even fake “royal notices.” Though they began as a small crew of penetration testers gone rogue, they’ve evolved into a disciplined operation targeting global trade, shipping, and supply chain entities.

**Motivation/Intent:**  
Primarily **espionage** and **economic advantage** — stealing trade route data, port logistics, and shipping manifests to benefit state interests and domestic industry. They also dabble in **financial gain** when an opportune target presents itself.

**Primary Sectors Targeted:**

- Shipping & Maritime Logistics
    
- Port Authorities & Customs Agencies
    
- International Trade & Freight Forwarding
    
- Energy (Offshore Drilling, LNG Terminals)
    
- Global Supply Chain Management
    

**Unique Characteristics:**

- Embeds subtle nautical puns in phishing lures (e.g., “Dock your password here”)
    
- Often uses decoy documents like fake maritime weather advisories or customs clearance forms
    
- Known to exploit _maritime satellite communication systems_ rarely monitored by security teams
    
- Deploys lightweight, modular malware disguised as “shipping invoice macros”
    

---

## **APT-PhishAndChips – TTPs**

| Technique ID  | Technique                           | Description of Technique                                                                                                                 | Tools Used                            |
| ------------- | ----------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------- |
| T1566.001 | Spearphishing Attachment            | Delivers malicious macros via fake customs clearance forms, port authority notices, or trade compliance checklists.                      | _NetAnchor_, _MacroDock_, _RoyalHook_ |
| T1071.004 | Application Layer Protocol: DNS     | Uses DNS tunneling to exfiltrate stolen manifest and shipping route data from air-gapped maritime control networks.                      | _SeaTunnel_, _Binnacle_               |
| T1091     | Replication Through Removable Media | Spreads malware via infected USB drives labeled as “Ship Safety Inspection Reports” for onboard engineers.                               | _HarborKey_                           |
| T1105     | Ingress Tool Transfer               | Deploys secondary payloads (keyloggers, RATs) via compromised port authority servers to connected vessels.                               | _CargoDrop_, _TrawlRAT_               |
| T1027     | Obfuscated Files or Information     | Encodes exfiltrated documents in image files of maritime maps to evade DLP solutions.                                                    | _MapMask_, _ChartCrypt_               |
| T1204.002 | User Execution: Malicious File      | Relies on dockside staff and customs agents being tricked into opening “shipping invoice” Excel files with embedded PowerShell droppers. | _TeaShell_, _ManifestLoader_          |
| T1190     | Exploit Public-Facing Application   | Targets poorly patched maritime cargo tracking portals to gain initial access.                                                           | _HarborBreak_, _TideSurf_             |
| T1005     | Data from Local System              | Collects cached maritime comms, GPS route plans, and weather forecasts from infected shipboard PCs.                                      | _StormCatch_, _RouteSpy_              |
| T1041     | Exfiltration Over C2 Channel        | Uses HTTPS-based C2 disguised as legitimate maritime weather API traffic.                                                                | _BuoyBeacon_, _WaveCtrl_              |
| T1486     | Data Encrypted for Impact           | Selectively encrypts port scheduling databases to delay cargo transfers, often as a distraction during data theft.                       | _DockLock_, _ManifestCrypt_           |