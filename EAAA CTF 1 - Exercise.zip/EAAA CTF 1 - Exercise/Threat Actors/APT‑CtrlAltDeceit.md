### 🕵️ Threat Actor Profile: **APT-CtrlAltDeceit**

**Overview:**  
APT-CtrlAltDeceit is a cunning, multi-faceted threat actor specializing in **manipulation, deception, and information operations** alongside traditional cyber intrusions. Believed to be a state-sponsored group with ties to influence operations, they combine **psychological manipulation**, **disinformation**, and **cyber-espionage** tactics. Active since at least 2016, this actor targets **media, political organizations, NGOs, and international policy think tanks**.

**Motivation:**  
Their core intent is **geopolitical influence, psychological operations, and data manipulation**—including falsifying or leaking data to serve a specific narrative. Espionage and data theft are secondary goals supporting the main influence objective.

**Unique Characteristics:**

- Deploys falsified documents or modified leaks to create diplomatic tension.
    
- Uses compromised media platforms and botnets to amplify stolen or fake data.
    
- Known for timed "leak drops" that align with key elections, policy decisions, or military actions.
    
- Combines cyber tactics with coordinated social media campaigns.
    

---

### 🧰 Tactics, Techniques, and Procedures

| Technique ID  | Technique                                      | Description of Technique                                                                                | Tools Used                                      |
| ------------- | ---------------------------------------------- | ------------------------------------------------------------------------------------------------------- | ----------------------------------------------- |
| T1566.002 | Phishing: Spearphishing via Link               | Sends phishing links disguised as access to leaked political or activist materials.                     | “ClickBaitDropper”, custom GoPhish kits         |
| T1496     | Resource Hijacking                             | Uses compromised infrastructure to host bot-driven fake news amplification.                             | SocialBotnet, TwisterOS, Apache rewrite modules |
| T1204.002 | User Execution: Malicious File                 | Distributes trojanized PDFs and video files purporting to be "exclusive leaks".                         | TrojanDocGen, LeakPlayer                        |
| T1557.002 | Adversary-in-the-Middle: ARP Cache Poisoning   | Conducts LAN-level spoofing attacks on activist organizations’ networks to intercept and alter content. | Bettercap, Responder                            |
| T1583.004 | Acquire Infrastructure: Server                 | Rents VPS hosting in various countries to stage fake NGO websites and disinformation portals.           | Vultr, DigitalOcean APIs                        |
| T1565.002 | Data Manipulation: Stored Data Manipulation    | Alters diplomatic emails and PDFs prior to leaks to create false narratives.                            | ForgeDoc, MetaSpoof                             |
| T1203     | Exploitation for Client Execution              | Exploits browser and plugin flaws via malicious iframe-loaded landing pages.                            | BrowserPack, CVEkit                             |
| T1027     | Obfuscated Files or Information                | Obfuscates both malware and document content to avoid detection and content scans.                      | Base64Drop, FakeSign                            |
| T1110.001 | Brute Force: Password Guessing                 | Performs targeted guessing on VIP accounts, especially journalists and political aides.                 | Hydra, Patator                                  |
| T1588.003 | Obtain Capabilities: Code Signing Certificates | Acquires stolen or fraudulent certs to sign malicious documents and scripts.                            | CodeSignForge, CertSnake                        |