### 🕵️ Threat Actor Profile: **APT-BitByBit**

**Overview:**  
APT-BitByBit is a methodical, data-centric threat actor that specializes in **slow, granular exfiltration of sensitive data**. Active since 2018, the group is believed to operate out of Southeast Asia with a focus on **industrial espionage**, particularly targeting **semiconductor firms, biotech research, aerospace engineering, and intellectual property law firms**. What makes APT-BitByBit unique is its **commitment to stealth over speed**—favoring byte-level exfiltration over long periods, often going unnoticed for months.

**Motivation:**  
**Intellectual property theft** and **economic espionage**. Often attributed to support strategic industrial growth or suppress competitive R&D.

**Targeted Sectors:**  
**Manufacturing, aerospace, pharmaceuticals, and legal services** tied to patent portfolios and trade secret management.

**Unique Characteristics:**

- Rarely exfiltrates whole files; breaks data into chunks and reassembles externally.
    
- Favors covert communication channels, like DNS tunneling or Bluetooth relays.
    
- Blends LOtL techniques with custom steganography tools to move data undetected.
    
- Coordinates with third-party initial access brokers, occasionally sharing infrastructure with groups like **APT-PasteTense**.
    

---

### 🧰 Tactics, Techniques, and Procedures

| Technique ID  | Technique                                                    | Description of Technique                                                                       | Tools Used                          |
| ------------- | ------------------------------------------------------------ | ---------------------------------------------------------------------------------------------- | ----------------------------------- |
| [[T1048.003]] | Exfiltration Over Alternative Protocol: DNS                  | Chunks sensitive data into base32 packets and tunnels it via DNS requests.                     | DNSplice, SlowFox                   |
| T1567.002     | Exfiltration Over Web Service: Exfiltration to Cloud Storage | Uploads small encrypted fragments to multiple anonymous cloud platforms.                       | rclone (heavily modified), BitShred |
| T1140         | Deobfuscate/Decode Files or Information                      | Breaks apart encoded documents for staged reassembly on attacker-controlled infrastructure.    | ByteDecoder, EncSplit               |
| T1059.003     | Command and Scripting Interpreter: Windows Command Shell     | Uses batch scripts for persistence and execution, echoing some APT-LivingOffTheLOLz behaviors. | cmd.exe, StealthScript              |
| T1136.001     | Create Account: Local Account                                | Creates low-privilege, hidden user accounts for long-term persistence.                         | useradd, PowerUserCreate            |
| T1010         | Application Window Discovery                                 | Identifies R&D environments or CAD software in use to prioritize targets.                      | WinDetect, GUIHunter                |
| T1497.003     | Virtualization/Sandbox Evasion: Time Based Evasion           | Delays execution based on environment clock drift or lack of system entropy.                   | ChronoBait, TimeCheck               |
| T1057         | Process Discovery                                            | Constantly maps running processes to detect security tools and adapt techniques.               | SysList, ProcessMask                |
| T1560.003     | Archive Collected Data: Custom Archive Format                | Compresses and encrypts small pieces of files with proprietary format and naming obfuscation.  | BitPack, EnigmaChunk                |
| T1583.006     | Acquire Infrastructure: Web Services                         | Purchases throwaway web hosting to serve as fragmented data reassembly endpoints.              | GhostHost, BitStackServer           |