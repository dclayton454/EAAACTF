## **APT-ClickBaitAndSwitch – Threat Actor Profile**

**Overview**  
APT-ClickBaitAndSwitch is a deceptive, highly adaptive cyber threat group notorious for luring victims into malicious engagement through irresistible _clickbait content_, only to “switch” tactics mid-operation for deeper infiltration. First reported in 2021, this group is believed to operate from a loosely affiliated coalition of cyber mercenaries based in multiple jurisdictions, using layered disinformation campaigns as both bait and smokescreen.

**Operational Style**  
They excel at creating believable social engineering hooks: fake trending news stories, “urgent” corporate policy changes, fraudulent giveaway campaigns, and manufactured leaks. Once initial trust is gained, they pivot from low-impact interactions (e.g., benign-looking content or downloads) to deploying advanced persistence mechanisms and lateral movement.

**Primary Motivation / Intent**

- **Primary:** Financial gain via credential theft, ad fraud, and ransomware deployment
    
- **Secondary:** Corporate espionage for hire, specifically targeting marketing and media analytics data
    

**Primary Target Sectors**

- Digital marketing & advertising agencies
    
- News media outlets
    
- Social media platforms
    
- E-commerce & online retail
    
- Streaming content providers
    

**Notable Traits**

- Masters of psychological timing: often launch clickbait campaigns during major news cycles for maximum traction
    
- Uses “pre-infection decoys” — harmless first-stage payloads to establish user comfort before triggering malicious second stage
    
- Known for creating fake _SEO booster tools_ as trojanized utilities
    

---

## **APT-ClickBaitAndSwitch – MITRE ATT&CK-Mapped TTPs**

| Technique ID  | Technique                                            | Description of Technique                                                                                                                                      | Tools Used                                                                                 |
| ------------- | ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| T1566.002 | Phishing: Spearphishing Link                         | Crafting highly shareable clickbait links tailored to a target’s industry trends, often embedded in fake news articles or “breaking leak” stories             | Custom CMS “BaitPress” for generating fake articles; Link shorteners with tracking beacons |
| T1189     | Drive-by Compromise                                  | Hosting malicious JavaScript on ad-networks and compromised influencer blogs; initial pages appear benign, switching to exploit kits only after repeat visits | Exploit kit “SwitchBlade” with timed activation scripts                                    |
| T1204.002 | User Execution: Malicious File                       | Disguising malware droppers as free “social engagement analytics tools” or “SEO optimizers” promoted through clickbait articles                               | Trojanized software “TrendBoost”                                                           |
| T1071.001 | Application Layer Protocol: Web Protocols            | C2 communications hidden within seemingly legitimate ad network traffic patterns                                                                              | “AdFlux” C2 framework blending into HTTP/S ad delivery channels                            |
| T1547.001 | Boot or Logon Autostart Execution: Registry Run Keys | Persistence via Windows registry keys masked as “AdHelper” services                                                                                           | Custom persistence injector “KeySwitch”                                                    |
| T1078     | Valid Accounts                                       | Post-phish use of stolen social media manager accounts to distribute additional clickbait at scale                                                            | Credential harvester “PassSnatch Pro”                                                      |
| T1027     | Obfuscated Files or Information                      | Payloads embedded within image metadata or CSS files of clickbait pages                                                                                       | Steganography tool “PixHide”                                                               |
| T1567.002 | Exfiltration Over Web Service                        | Stolen marketing and consumer analytics data sent to attacker-controlled “ad verification” platforms                                                          | Modified open-source exfil tool “DataStream-Shift”                                         |
| T1486     | Data Encrypted for Impact                            | Selective ransomware deployment on ad server infrastructures to extort large media agencies                                                                   | Ransomware variant “BannerLock”                                                            |