### Version3 Security News

A major **European fintech provider** disclosed that attackers accessed its cloud platform using stolen **OAuth tokens (T1528)**. Logs showed that once authenticated, the adversaries performed **cloud service discovery (T1526)** to map available storage buckets. Analysts confirmed multiple downloads of sensitive customer files, consistent with **data from cloud storage (T1530)**.

Connections to `cdn-update[.]net` and `cloudsync-storage[.]com` were flagged during the incident, although both domains have appeared in ransomware and botnet cases unrelated to fintech. Analysts also recovered a binary tied to hash `ac12f9e4728d891b01e214d45c72e3f0`, which was previously linked to exfiltration tools in retail-sector compromises.

Despite these overlaps, responders noted the **entire intrusion was cloud-native**, relying on stolen identity tokens and platform services. “They didn’t need custom malware,” one analyst remarked. “They used the cloud exactly as designed — just with stolen keys.”