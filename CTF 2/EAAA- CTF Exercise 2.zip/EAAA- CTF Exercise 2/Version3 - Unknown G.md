### Version3

Investigators at a **telecommunications provider** disclosed a breach where attackers exploited a **public-facing application (T1190)** to gain initial access. Once inside, the adversaries attempted widespread **password spraying (T1110.003)** against remote access portals, which yielded several working accounts. With these, they established persistence and began tunneling traffic through the corporate DNS service, a technique consistent with **DNS tunneling (T1071.004)**.

During the review, analysts noted suspicious outbound connections to `vpn-gateway[.]org` and `103.56.21[.]118`. Both indicators have also been observed in ransomware and disinformation campaigns, leading some responders to suspect deliberate planting of false evidence.

Despite these overlaps, investigators emphasized the **combination of telecom sector targeting, exploitation of web apps, credential abuse, and DNS tunneling** as the reliable pattern. “The indicators are noisy,” one responder said, “but the behaviors are telling.”