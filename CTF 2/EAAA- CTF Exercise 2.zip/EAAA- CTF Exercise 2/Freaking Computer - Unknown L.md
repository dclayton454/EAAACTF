### Freaking Computer

The mining company confirmed the attackers moved laterally across several divisions, copying project files related to rare-earth extraction and environmental studies. Engineers first flagged the incident when automated workflows started failing due to locked or missing files.

Logs showed that intruders had quietly scheduled transfers, moving small batches of documents late at night. This behavior avoided detection by data-loss monitoring, which is typically tuned to spot large spikes. Investigators said the attackers displayed deep knowledge of both the company’s workflow and how to blend in with its traffic patterns.

Unlike ransomware or opportunistic breaches, the attackers made no attempt to monetize immediately. Instead, the intrusion focused on **exfiltrating valuable industrial data**, a classic espionage hallmark.