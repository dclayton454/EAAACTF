### Crabs on Security

The breach of a Nordic steel manufacturer highlights the **convergence of espionage and cybercrime**. The attackers sought to capture sensitive industrial data while exploiting spare compute resources for cryptocurrency mining. This dual-use approach demonstrates how state-aligned and criminal incentives can blur.

Officials noted that no ransom demands were made, and disruption was minimal. Instead, the adversaries operated quietly, positioning themselves to **extract long-term value** from both stolen designs and diverted computing power. Analysts warned that such hybrid campaigns are increasingly common, especially in resource-intensive industries where high-performance servers can double as mining farms.

Policymakers argue that the case illustrates a critical vulnerability in industrial sectors: the assumption that intellectual property theft and financial crime are separate threats. In reality, modern adversaries combine them for maximum yield.