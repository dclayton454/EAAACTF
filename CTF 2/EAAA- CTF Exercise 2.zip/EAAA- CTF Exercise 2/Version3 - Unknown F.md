### Version3 Security News 

A European **telecom billing provider** suffered a breach in which attackers infiltrated servers and created multiple **new local accounts (T1136.001)**. These accounts were disguised to look like dormant administrators, enabling the attackers to blend into normal activity. Forensic teams later discovered large datasets compressed into archives (**T1560.001**) and staged for exfiltration.

Outbound connections were traced to `cloudsync-storage[.]com`, an endpoint seen in prior ransomware and botnet campaigns. Investigators also identified a familiar hash (`ac12f9e4728d891b01e214d45c72e3f0`) associated with exfiltration tooling, though it has also surfaced in cloud espionage cases. Logs showed final activity involving database locks and encrypted volumes (**T1486 – Data Encrypted for Impact**), which temporarily crippled billing services.

Analysts cautioned that the **IOCs overlapped with multiple unrelated operations**, but the tactics — creating new accounts, staging billing data, and triggering selective encryption — point clearly toward an extortion-focused adversary.