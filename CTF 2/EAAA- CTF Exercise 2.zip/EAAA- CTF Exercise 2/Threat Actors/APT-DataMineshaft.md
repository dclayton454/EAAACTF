# APT-DataMineshaft

**Description**  
DataMineshaft is a dossier machine aimed squarely at mining and rare-earth value chains. Access is often gained through targeted attachments to geologists and BD staff, followed by thorough account enumeration and mapping of shared drives that hold surveys, assays, and contract drafts. They stage everything—carefully curated folder trees, renamed archives, and manifests—before initiating slow scheduled transfers during maintenance windows. Domain trust mapping helps them identify cross-subsidiary relationships and regulator touchpoints for follow-on collection. They favor keylogging to capture document passwords and signatures, and their exfiltration is measured, predictable, and easy to miss without long-horizon telemetry.

**Targeted Sectors**

- Mining & Resources
    
- Government (resource regulators)
    
- Energy
    
- Healthcare (medical research linked to rare-earths)
    

**Motivation**

- Primary: State-linked economic espionage
    
- Secondary: Strategic leverage in commodity negotiations
    

**ATT&CK Technique Set**

|Tactic|Technique|ATT&CK ID|Notes|
|---|---|---|---|
|Initial Access|Phishing: Attachment|**T1566.001**|Targeted docs|
|Discovery|Account Discovery|**T1087**|People/roles|
|Collection|Data from Network Shared Drive|**T1039**|Shared stores|
|Collection|Data from Local System|**T1005**|Workstations|
|Collection|Data Staged|**T1074**|Curated sets|
|Exfiltration|Scheduled Transfer|**T1029**|Nightly jobs|
|Discovery|Domain Trust Discovery|**T1482**|Cross-org paths|
|Collection|Keylogging|**T1056.001**|Doc passwords|
|Exfiltration|Exfiltration Over C2|**T1041**|Small batches|