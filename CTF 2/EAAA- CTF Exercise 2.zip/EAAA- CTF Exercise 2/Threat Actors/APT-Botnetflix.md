# APT-Botnetflix

**Description**  
APT-Botnetflix treats the internet like a giant amplifier: they conscript vast herds of compromised IoT devices and SoHo routers to create distracting noise while a smaller core team slips in to do the real work. Campaigns typically begin with wide-area scanning and DDoS to mask credential-stuffing and opportunistic exploitation, then shift to fast reconnaissance of NAS appliances and Windows file shares for data staging. Their tradecraft is cheap and ruthlessly automated—dynamic DNS, throwaway VPS relays, commodity loaders—but they mix in just enough hands-on-keyboard to grab what matters and leave. When money is the goal, they push toward DDoS extortion or smash-and-grab ransomware; when hired, the same botnet noise cloaks short, targeted espionage sorties. Infrastructure is high-churn and look-alike, with recycled C2 paths and CDN-adjacent Web C2 that blends into normal traffic baselines. Defenders often misread the storm as the objective; with Botnetflix, the storm is the smokescreen.

**Targeted Sectors**

- Telecom & ISPs
    
- Media/Streaming
    
- Retail/e-commerce
    
- Energy/Utilities
    

**Motivation**

- Primary: Financial (extortion, opportunistic ransomware)
    
- Secondary: Contract espionage under “botnet-as-a-service”
    

**ATT&CK Technique Set**

| Tactic            | Technique                       | ATT&CK ID         | Notes                           |
| ----------------- | ------------------------------- | ----------------- | ------------------------------- |
| Impact            | Network DoS                     | **T1498**         | DDoS cover for intrusion phases |
| Recon             | Network Service Scanning        | **T1046**         | Internet-wide probes via bots   |
| Command & Control | Application Layer Protocol: Web | **[[T1071.001**]] | CDN/CDN-like paths for C2       |
| Defense Evasion   | Proxy/Relay                     | **T1090**         | Multi-hop relays/VPS chains     |
| Exfiltration      | Exfiltration Over C2 Channel    | **T1041**         | Small, fast egress during noise |
| Discovery         | Network Share Discovery         | **T1135**         | Quick wins on exposed SMB/NAS   |
| Lateral Movement  | SMB/Windows Admin Shares        | **T1021.002**     | Copy & service-create           |
| Discovery         | Remote System Discovery         | **T1018**         | Find pivotable hosts            |
| Command & Control | Dynamic Resolution              | **T1568**         | Fast-flipping DDNS for infra    |
