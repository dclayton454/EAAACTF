### Freaking Computer

Customers across Europe reported streaming outages after multiple platforms were hit with a flood of malicious traffic. Engineers scrambled to reroute connections and scale up mitigation tools. But as the front-end chaos unfolded, attackers used the distraction to quietly probe service-provider networks.

Investigators found that during the outages, unusual login attempts were made against internal servers. In some cases, administrative shares were accessed, and customer data directories were quietly copied. The attackers appeared to leverage compromised consumer devices, coordinating them into a botnet capable of both **disruption and infiltration**.

What alarmed defenders was the attackers’ restraint: instead of fully encrypting systems or openly extorting, they seemed content to **build footholds** inside ISPs, laying the groundwork for future access.