### Version3

A major **gaming platform** disclosed an incident after players reported account takeovers and in-game currency theft. Investigators traced the compromise to malicious browser extensions that harvested stored credentials (**T1555.003 – Credentials from Web Browsers**). Once stolen, the logins were resold on underground forums and used to gain direct access to player accounts.

Forensic teams found that infected machines also executed unauthorized crypto-mining workloads (**T1496 – Resource Hijacking**). Hosts connected intermittently to `45.77.213[.]82`, an address previously seen in ransomware and telecom extortion cases. Analysts also recovered persistence via registry modifications (**T1547.001 – Registry Run Keys/Startup Folder**), ensuring the extensions reloaded at each boot.

Although the IOC overlaps with other known incidents, responders concluded the **combination of browser credential theft, illicit mining, and persistence through registry keys** indicated a criminal group with strong ties to gaming and cryptocurrency abuse.