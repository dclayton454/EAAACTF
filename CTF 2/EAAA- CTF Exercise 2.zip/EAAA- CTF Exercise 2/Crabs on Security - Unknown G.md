### Crabs on Security

The compromise of a European telecom provider highlights the **vulnerability of core communications infrastructure**. By exploiting web portals and abusing weak credentials, attackers gained persistent access and masked their activity through DNS tunneling.

Officials said the campaign showed no evidence of ransom demands or destructive activity. Instead, the attackers appeared intent on **long-term espionage**, collecting data on communications traffic and internal infrastructure. Analysts stressed that this aligns with wider campaigns targeting telecoms as “backbone intelligence sources.”

The case illustrates a broader systemic risk: if telecom operators are infiltrated, the attackers gain visibility across entire regions. As one EU official commented, _“Telecoms are the nervous system of a nation — and adversaries know it.”_