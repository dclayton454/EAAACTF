### Version3

A European **MSSP** reported a breach in which attackers deployed fake update installers across customer environments. The files were disguised to look like legitimate vendor packages, a form of **masquerading (T1036)**. In parallel, analysts discovered DNS traffic patterns consistent with **command-and-control tunneling (T1071.004)** and obfuscated payloads packed with custom encryption layers (**T1027.002**).

Several of the fake update packages connected to `mediahub-news[.]info` and `103.56.21[.]118`. Both have been linked in past quarters to influence campaigns and unrelated industrial espionage cases, confusing attribution. Investigators stressed that these overlaps are not conclusive but may reflect **intentional false flags**.

Despite this, responders concluded the **blend of fake update lures, DNS-based C2, and obfuscation** was the actor’s defining signature.