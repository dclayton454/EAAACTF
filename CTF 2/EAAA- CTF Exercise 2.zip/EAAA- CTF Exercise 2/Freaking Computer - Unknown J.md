### Freaking Computer

The metals manufacturer confirmed that attackers gained initial access through a single compromised engineering account. From there, they issued remote PowerShell commands to move laterally across servers, focusing on repositories containing design schematics and production schedules.

While the attackers quietly exfiltrated intellectual property, they also installed crypto-mining tools on underutilized infrastructure. Several servers saw CPU usage spike dramatically during off-hours, causing delays in legitimate workloads. Administrators eventually traced the activity to scripts planted in scheduled tasks, which re-launched miners even after clean-up attempts.

Investigators also discovered that logging agents had been disabled, leaving significant gaps in visibility. Experts concluded the attackers’ **dual motive** was clear: steal valuable IP while simultaneously monetizing idle resources.