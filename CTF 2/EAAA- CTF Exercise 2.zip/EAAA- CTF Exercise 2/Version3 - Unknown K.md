### Version3

Multiple European **streaming services** were knocked offline in a coordinated cyberattack that investigators say blended disruption with deeper network probing. Logs showed waves of denial-of-service traffic targeting customer-facing platforms (**T1498 – Network DoS**) during peak hours, overwhelming ISPs and generating widespread outages.

While defenses focused on restoring availability, forensic teams uncovered parallel **scanning activity (T1046 – Network Service Discovery)** inside ISP networks. In several cases, the attackers attempted to spread laterally using administrative shares (**T1021.002 – SMB/Windows Admin Shares**). Outbound connections were traced to `cdn-update[.]net` and `cloudsync-storage[.]com`, domains linked to cloud and botnet campaigns elsewhere. Analysts also noted traffic toward `185.193.90[.]34`, an address long associated with ransomware infrastructure.

Despite this overlap, responders concluded the attack’s **dual nature — DDoS smokescreen plus lateral exploration of ISP networks** — matched the tradecraft of a known botnet-enabled adversary.