### Version3

A **Scandinavian metals manufacturer** reported a compromise after discovering unusual PowerShell activity on engineering servers. Forensic review confirmed adversaries relied on **PowerShell remoting (T1059.001)** for lateral movement, pivoting from an initially compromised workstation into design repositories.

The attackers deployed mining software across several unused servers, a clear case of **resource hijacking (T1496)**. At the same time, they tampered with endpoint defenses by disabling local logging and antivirus services (**T1562.001 – Impair Defenses**). Network captures revealed repeated connections to `103.56.21[.]118`, a host previously linked to telecom espionage, and a destructive loader hash (`91dd23f54a12e9d8e3f71cc8a8d2e5a7`) that had also surfaced in wiper cases.

Although these IOCs suggested multiple attribution paths, investigators stressed the **industrial targeting, PowerShell lateral movement, and parallel cryptomining** as the defining signature of the intrusion.