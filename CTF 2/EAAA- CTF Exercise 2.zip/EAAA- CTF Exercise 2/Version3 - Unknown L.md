### Version3

A major **mining conglomerate** reported a breach after unusual file movements were spotted across internal engineering servers. Investigators determined that attackers collected sensitive geological survey results and intellectual property by pulling files from shared network drives (**T1039 – Data from Network Shares**). The stolen data was then **staged internally (T1074)** before being exfiltrated in scheduled transfers (**T1029 – Scheduled Transfer**).

One suspicious connection was logged to `mediahub-news[.]info`, a domain previously linked to disinformation campaigns and unrelated financial breaches. Analysts noted that the overlap raised the possibility of deliberate misdirection.

Despite this, the attack sequence — file collection, staging, and careful exfiltration — led responders to conclude the adversary was motivated by **long-term economic espionage** rather than cybercrime.