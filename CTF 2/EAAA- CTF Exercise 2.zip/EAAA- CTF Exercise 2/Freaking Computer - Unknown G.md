### Freaking Computer

The telecom firm reported that the attackers initially breached a customer self-service portal by exploiting an unpatched web vulnerability. From there, they attempted to log into dozens of accounts using broad password attempts. Several older accounts were compromised, giving the intruders a foothold into the internal network.

Once inside, the attackers rerouted command-and-control traffic through the company’s DNS servers, disguising their communications as routine name lookups. Logs showed unusual but subtle spikes in DNS traffic at odd hours, which were only detected after cross-team correlation.

The attackers avoided ransomware or immediate disruption. Instead, they mapped out infrastructure and quietly accessed sensitive call-record systems. Experts believe the operation was designed to gather **long-term intelligence on telecom operations** rather than extort the victim directly.