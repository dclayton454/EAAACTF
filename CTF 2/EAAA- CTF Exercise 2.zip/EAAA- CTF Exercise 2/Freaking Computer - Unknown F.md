### Freaking Computer

The telecom billing firm confirmed that attackers quietly built persistence by setting up hidden administrative accounts. These accounts allowed the intruders to move freely across servers and access sensitive customer data without tripping alarms.

Over the course of several days, the attackers compressed records into large archives. Once staging was complete, the files were exfiltrated through cloud connections disguised as routine traffic. Immediately afterward, employees reported sudden access denials to core databases — a symptom of encryption attacks triggered by the intruders.

Executives said there was no ransom demand on day one, but investigators noted the sequence was consistent with **steal-and-extort campaigns**: take valuable data, encrypt core systems, and then pressure the victim once leverage is maximized.