### Version3 Security News (operational, actor not named)

Analysts investigating a breach at a major **European port authority** discovered that attackers used phishing emails containing malicious attachments **(T1566.001)** to gain their initial foothold. Victims received messages spoofing a shipping registry, which delivered weaponized documents disguised as customs updates.

Forensic review showed the attackers escalated privileges by re-using stolen domain credentials (**T1078**). Several accounts authenticated into remote VPN gateways in the days after the phishing wave. A malicious payload associated with the incident was tied to hash e3f6b4c8a19d77f0afee3b21cd7b89d4, though this same hash has been observed in supply-chain compromises unrelated to port operations. Logs also recorded outbound connections to login-microsoft-secure[.]com and royalpost-sec[.]uk— both domains seen in other phishing and influence campaigns.

While the overlap with multiple unrelated incidents complicates attribution, investigators stressed that the **maritime sector targeting**, **phishing lures**, and **credential abuse via VPN** remain the strongest clues to the group’s identity.