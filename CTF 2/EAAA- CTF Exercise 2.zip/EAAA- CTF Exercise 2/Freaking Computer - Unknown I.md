### Freaking Computer

The gaming company confirmed attackers distributed what appeared to be performance-boosting add-ons through unofficial download sites. Players who installed them unknowingly gave the attackers access to browser-stored credentials, which were then used to hijack accounts and drain wallets tied to in-game purchases.

Administrators also noted a surge in CPU usage across compromised machines. Analysts later confirmed the add-ons quietly ran mining scripts that diverted resources toward cryptocurrency generation. Some players complained of overheating laptops and sudden crashes, initially thinking it was a hardware bug before the real cause became apparent.

The attackers persisted by ensuring the extensions automatically reinstalled even after manual removal. The campaign blended profit motives: **credential resale on underground markets and revenue through crypto-mining**, giving the attackers multiple income streams without overt ransom demands.