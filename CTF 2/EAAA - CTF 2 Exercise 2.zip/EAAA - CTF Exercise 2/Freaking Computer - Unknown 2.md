### Freaking Computer (tactical, actor not named)

The incident at a European port authority began with carefully crafted emails disguised as customs and import notices. Staff members who opened the attachments triggered malware that immediately attempted to authenticate to internal services.

Soon after, administrators noticed suspicious VPN logins originating from legitimate employee accounts. Investigators said the attackers had stolen credentials during the phishing phase and then reused them to gain deeper access. Once inside, they quietly explored file shares tied to cargo tracking and scheduling. Small bundles of documents were staged internally and exfiltrated over secure connections in the weeks that followed.

The attack showed no signs of ransomware or destructive behavior. Instead, the focus was on **maintaining long-term access to sensitive trade data**.