### Version3 

Incident responders at a national **energy regulator** confirmed that attackers deployed a malicious driver that disabled endpoint protection across multiple workstations (**T1562.004 – Disable Security Tools**). Shortly after defenses were impaired, several critical servers were wiped of data (**T1485 – Data Destruction**).

Network telemetry showed outbound communications to `vpn-gateway[.]org` and `185.193.90[.]34`, both of which have been observed in unrelated ransomware and supply chain campaigns. Analysts also recovered a hash (`91dd23f54a12e9d8e3f71cc8a8d2e5a7`) tied to destructive loaders used previously in manufacturing-sector compromises.

Despite the overlap, investigators highlighted the operational sequence — **targeting of government/energy, disabling of defenses, destructive wiping, and lateral use of remote desktop (T1021.001)** — as pointing to a well-resourced state-aligned actor.