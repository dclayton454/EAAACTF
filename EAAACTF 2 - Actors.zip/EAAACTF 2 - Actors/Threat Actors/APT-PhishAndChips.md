# APT-PhishAndChips

**Description**  
APT-PhishAndChips wins hearts, minds, and credentials with wry British humor and maritime-flavored social engineering. Lures impersonate port authorities, freight forwarders, or “Royal” entities and lead to cloud sign-in portals and link-delivered implants. After first access, the group favors living-off-the-land: PowerShell for discovery and staging, password spraying against VPN and Microsoft 365, and steady expansion via reused RDP/VPN credentials. Their target environments—shipping, customs, and offshore energy—reward patient reconnaissance of supply-chain data and route planning systems, so they often exfiltrate quietly and continuously rather than in single big bursts. Infrastructure is tidy and reusable with overlapping certificate fingerprints and recurring registrar choices that give them away to careful analysts. They seldom break things; disruption risks the long view they prefer.

**Targeted Sectors**

- Shipping & Logistics
    
- Energy (offshore)
    
- Finance (trade finance, insurers)
    
- Government (customs, port authorities)
    

**Motivation**

- Primary: Espionage (trade/logistics intelligence)
    
- Secondary: Opportunistic fraud when viable
    

**ATT&CK Technique Set**

| Tactic            | Technique                         | ATT&CK ID     | Notes                  |
| ----------------- | --------------------------------- | ------------- | ---------------------- |
| Initial Access    | Phishing: Link                    | **T1566.002** | Logistics-themed lures |
| Initial Access    | Exploit Public-Facing Application | **T1190**     | Unpatched portals      |
| Persistence       | External Remote Services          | **T1133**     | VPN/RDP footholds      |
| Defense Evasion   | Valid Accounts                    | **T1078**     | Reuse of stolen creds  |
| Execution         | PowerShell                        | **T1059.001** | LoTL post-ex           |
| Credential Access | Password Spraying                 | **T1110.003** | O365/VPN targets       |
| Credential Access | OS Credential Dumping             | **T1003**     | LSASS, SAM             |
| Exfiltration      | Exfiltration Over C2              | **T1041**     | Trickle exfil          |

