# APT-NordicSteel

**Description**  
NordicSteel straddles IT and industrial IT, pilfering IP while quietly monetizing spare compute with miners. They move with administrator tools—PowerShell remoting, WMI, PsExec—and rely on SMB/Admin shares for lateral movement that looks like routine maintenance. Their miners are intentionally under-tuned to avoid alarms in production, and their data theft often piggybacks on the same channels used for remote admin. They impair defenses just enough to reduce noise without blinding SOCs outright, and they escalate privileges through misconfigurations rather than flashy exploits. The result: long dwell, slow bleed, and a ledger that balances espionage and side profit.

**Targeted Sectors**

- Manufacturing (industrial IP)
    
- Energy
    
- Mining & Resources
    
- Finance (commodity traders)
    

**Motivation**

- Primary: Economic espionage (designs, process data)
    
- Secondary: Financial (crypto-mining, access resale)
    

**ATT&CK Technique Set**

|Tactic|Technique|ATT&CK ID|Notes|
|---|---|---|---|
|Execution|PowerShell|**T1059.001**|Remoting & scripts|
|Execution|Windows Management Instrumentation|**T1047**|Inventory & tasks|
|Lateral Movement|SMB/Windows Admin Shares|**T1021.002**|File/service create|
|Lateral Movement|Lateral Tool Transfer|**T1570**|Copy toolkits|
|Impact|Resource Hijacking|**T1496**|Miners|
|Discovery|Network Sniffing|**T1040**|Cred/data sniff|
|Collection|Data from Local System|**T1005**|Engineering docs|
|Defense Evasion|Impair Defenses|**T1562.001**|EDR policy tweaks|
|Privilege Escalation|Abuse Elevation Control|**T1548**|UAC bypass|