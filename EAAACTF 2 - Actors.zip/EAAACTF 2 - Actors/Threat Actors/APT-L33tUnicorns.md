# APT-L33tUnicorns

**Description**  
Born in gamer forums and crypto channels, L33tUnicorns package trojans as cheats, mods, and “wallet boosters.” Their operations are messy but profitable: browser credential theft, quick-and-dirty miners, and occasional double-extortion ransomware when a whale appears. They favor self-install persistence (run keys, scheduled tasks), Telegram/Discord-style C2, and aggressive log cleaning that often breaks systems—burning victims but buying time. Infrastructure overlaps with affiliate ecosystems, so signatures and lures circulate widely and mutate quickly. They’re not the stealthiest group, but they are fast, adaptable, and everywhere their audiences congregate.

**Targeted Sectors**

- Gaming & eSports
    
- Retail/e-commerce
    
- Finance (consumer fraud/crypto)
    
- Media/Streaming
    

**Motivation**

- Primary: Financial (credential resale, crypto-mining, ransomware)
    
- Secondary: Access brokerage
    

**ATT&CK Technique Set**

|Tactic|Technique|ATT&CK ID|Notes|
|---|---|---|---|
|Initial Access|Phishing: Link|**T1566.002**|Forum/social lures|
|Persistence|Run Keys/Startup Folder|**T1547.001**|Self-start|
|Credential Access|Credentials from Web Browsers|**T1555.003**|Wallet/session theft|
|Credential Access|OS Credential Dumping|**T1003**|LSASS|
|Impact|Resource Hijacking|**T1496**|Crypto-mining|
|Execution|Command Shell|**T1059.003**|Batch scripts|
|Defense Evasion|Indicator Removal|**T1070**|Clear traces|
|Exfiltration|Exfiltration Over C2|**T1041**|Discord/HTTP|