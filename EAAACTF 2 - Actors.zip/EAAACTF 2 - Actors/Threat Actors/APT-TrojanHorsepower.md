# APT-TrojanHorsepower

**Description**  
APT-TrojanHorsepower is patient, quiet, and obsessed with trusted pathways. They compromise software supply chains and build systems to deliver signed, legitimate-looking components that survive audits and user suspicion. Once inside, they privilege persistence over speed, standing up Windows services and scheduled tasks that blend into operational tooling, only disabling defenses when absolutely necessary. Their hallmark is sparse but high-quality activity: minimal beaconing, meticulously packed loaders, and careful timestamp/metadata grooming to defeat timeline analysis. They often stage data on internal file servers for weeks before a timed exfiltration run, and they maintain multiple dormant persistence hooks to survive remediation. When detected, responders find a museum of subtle subversions rather than a smashed window. TrojanHorsepower focuses on on-prem persistence and file staging, rarely cloud-native.

**Targeted Sectors**

- Software Vendors
    
- Government IT
    
- Manufacturing
    
- Energy
    

**Motivation**

- Primary: Espionage (long-term access, sensitive IP)
    
- Secondary: Strategic positioning for future ops
    

**ATT&CK Technique Set**

|Tactic|Technique|ATT&CK ID|Notes|
|---|---|---|---|
|Initial Access|Supply Chain Compromise|**T1195**|Poisoned updates/builds|
|Defense Evasion|Subvert Trust Controls: Code Signing|**T1553.002**|Signed loaders|
|Persistence|Scheduled Task/Job|**T1053**|Timed jobs for dwell|
|Persistence|Windows Service|**T1543.003**|Blend with ops services|
|Defense Evasion|Signed Binary Proxy Execution|**T1218**|LOLBINS for stealth|
|Defense Evasion|Obfuscated/Encrypted Files|**T1027**|Packed payloads|
|Defense Evasion|Impair Defenses|**T1562.001**|Targeted tampering|
|Defense Evasion|Indicator Removal on Host|**T1070.004**|Clear artifacts|