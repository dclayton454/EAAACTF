# APT-SilkRoadRunners

**Description**  
SilkRoadRunners are the logisticians of the cybercriminal world: access brokers, RaaS affiliates, and data launderers with a preference for cloud egress. They create local accounts, move tooling laterally via SMB/Admin shares, archive what they find, and push it to cloud storage that then syncs into darknet delivery pipelines. Proxies and multi-hop relays compartmentalize each stage, making takedowns whack-a-mole. They’re opportunistic but disciplined—if a victim looks lucrative for encryption, they’ll shift gears into ransomware with familiar, templated notes and negotiated playbooks. Think business process, not hobby hacking.

**Targeted Sectors**

- Financial Exchanges
    
- Retail/e-commerce
    
- Telecom (fraud rings)
    
- Healthcare (extortion targets)
    

**Motivation**

- Primary: Financial (ransomware, access resale, data markets)
    
- Secondary: Services for other crews
    

**ATT&CK Technique Set**

|Tactic|Technique|ATT&CK ID|Notes|
|---|---|---|---|
|Persistence|Create Account: Local|**T1136.001**|Foothold pre-encryption|
|Defense Evasion|Proxy/Relay|**T1090**|Multi-hop chains|
|Exfiltration|Exfiltration to Cloud Storage|**T1567.002**|Cloud egress|
|Impact|Data Encrypted for Impact|**T1486**|RaaS phase|
|C2|Web Protocols|**T1071.001**|Commodity panels|
|Discovery|Account Discovery|**T1087**|Expansion targets|
|Lateral Movement|SMB/Windows Admin Shares|**T1021.002**|Copy & exec|
|Collection|Data from Local System|**T1005**|Harvest artifacts|
|Exfiltration|Archive Collected Data|**T1560.001**|Zip/rar staging|