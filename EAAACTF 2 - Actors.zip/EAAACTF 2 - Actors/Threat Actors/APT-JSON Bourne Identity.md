# APT-JSON Bourne Identity

**Description**  
This actor is cloud-native to the bone. They live in API consoles, serverless runtimes, and identity providers, quietly harvesting application tokens and reshaping cloud roles to persist without obvious endpoints to clean. Their entry vectors are depressingly modern: OAuth mis-scopes, CI/CD secrets in repos, inadvertently public buckets, and over-permissive service principals. Once in, they enumerate services with provider-specific tooling, automate exfiltration to attacker-controlled cloud accounts, and rotate short-lived credentials to evade detections that look for static keys. On-prem activity is minimal; most artifacts live in cloud logs that defenders rarely centralize well. If you don’t speak the language of your CSP, you won’t see them coming—or leaving. They rarely compromise software supply chains; instead, their access is almost always direct-to-cloud.

**Targeted Sectors**

- Cloud/SaaS
    
- Fintech
    
- Manufacturing (IoT/cloud-linked)
    
- Healthcare (patient portals, SaaS providers)
    

**Motivation**

- Primary: Espionage (data theft from cloud)
    
- Secondary: Monetization of datasets/access
    

**ATT&CK Technique Set**

|Tactic|Technique|ATT&CK ID|Notes|
|---|---|---|---|
|Credential Access|Steal Application Access Token|**T1528**|OAuth/session tokens|
|Defense Evasion|Valid Accounts: Cloud|**T1078.004**|Compromised service roles|
|Collection|Data from Cloud Storage|**T1530**|S3/Blob/GCS pulls|
|Discovery|Cloud Service Discovery|**T1526**|Enumerate services|
|Persistence|Account Manipulation|**T1098**|Roles, policies|
|Credential Access|Credentials in Files|**T1552.001**|CI/CD leaks|
|Exfiltration|Automated Exfiltration|**T1020**|Serverless jobs|
|Exfiltration|Exfiltration to Cloud Storage|**T1567.002**|Attacker cloud|
|Execution|Command/Scripting Interpreter|**T1059**|CSP CLIs/SDKs|