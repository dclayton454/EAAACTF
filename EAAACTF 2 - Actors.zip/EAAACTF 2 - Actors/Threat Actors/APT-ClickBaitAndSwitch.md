# APT-ClickBaitAndSwitch

**Description**  
APT-ClickBaitAndSwitch weaponizes attention economics: SEO-poisoned posts, viral “leaks,” and fake giveaways funnel victims to malicious files or drive-by pages. The initial touch is often low-stakes to build trust; the “switch” comes later with credential theft, persistence, and lateral movement hidden beneath continuous content churn. They run professional-grade influence infrastructure—sockpuppet farms, coordinated posting cadences, and link shorteners that mutate per campaign. Technically, they prefer browser and email data collection and staged archives pushed to cloud storage, minimizing on-prem signatures. They are noisy in public, quiet on endpoints, and durable across takedowns because content is the delivery mechanism as much as the malware.

**Targeted Sectors**

- Media & Marketing
    
- Retail/e-commerce
    
- Finance (ad tech, banking fraud)
    
- Political Advocacy/NGOs
    

**Motivation**

- Primary: Financial (ad fraud, credential resale)
    
- Secondary: Influence operations
    

**ATT&CK Technique Set**

|Tactic|Technique|ATT&CK ID|Notes|
|---|---|---|---|
|Initial Access|Drive-by Compromise|**T1189**|SEO-poisoned landings|
|Initial Access|Phishing: Attachment|**T1566.001**|“leak” docs|
|Resource Development|Establish Accounts|**T1585**|Sockpuppets|
|Execution|User Exec: Malicious File|**T1204.002**|Consent → payload|
|Defense Evasion|Obfuscated/Encrypted Files|**T1027**|Packed droppers|
|Credential Access|Credentials from Web Browsers|**T1555.003**|Token/cookie theft|
|Collection|Email Collection|**T1114**|Media org targets|
|Exfiltration|Archive Collected Data|**T1560.001**|Zip/rar staging|
|Exfiltration|Exfiltration to Cloud Storage|**T1567.002**|Low-friction egress|