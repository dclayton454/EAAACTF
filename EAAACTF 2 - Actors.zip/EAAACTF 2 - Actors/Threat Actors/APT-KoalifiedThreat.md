# APT-KoalifiedThreat

**Description**  
KoalifiedThreat is a methodical espionage shop with a telecom fixation across Oceania and SE Asia. They favor low-and-slow intrusions, exploiting edge devices and exposed apps, then burrowing inward with password spraying and careful account reuse. DNS tunneling and packed loaders keep their beacons small and hard to fingerprint, while VBScript and signed proxy execution help blend with legacy admin patterns in target environments. They archive before exfil, use role-based access changes for persistence, and avoid noisy actions that would force IR to mobilize. If you spot them, it’s probably because of disciplined repetition, not flamboyance.

**Targeted Sectors**

- Telecom
    
- Energy
    
- Government (regulators, ministries)
    
- Finance (banks, telecom-linked payment systems)
    

**Motivation**

- Primary: Espionage (communications intelligence)
    
- Secondary: Strategic footholds in regional infrastructure
    

**ATT&CK Technique Set**

|Tactic|Technique|ATT&CK ID|Notes|
|---|---|---|---|
|Initial Access|Exploit Public-Facing App|**T1190**|Edge device vulns|
|C2|Application Layer Protocol: DNS|**T1071.004**|DNS tunneling|
|Defense Evasion|Valid Accounts|**T1078**|Quiet re-use|
|Discovery|System Information Discovery|**T1082**|Host scoping|
|Defense Evasion|Software Packing|**T1027.002**|Loader morphing|
|Execution|VBScript|**T1059.005**|Legacy LoTL|
|Credential Access|Password Spraying|**T1110.003**|Telecom IDs|
|Exfiltration|Archive Data|**T1560**|Pre-egress staging|
|Defense Evasion|Signed Binary Proxy Exec|**T1218**|LOLBINS|